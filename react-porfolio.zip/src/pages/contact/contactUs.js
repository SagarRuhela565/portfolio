const contactUs = () => {
    return <h1>contactUs</h1>;
  };
  
export default contactUs;
  